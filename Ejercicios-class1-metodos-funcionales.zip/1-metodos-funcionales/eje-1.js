'use strict';

const marks = [5, 4, 6, 7, 9];

const inflatedMarks = marks.map(number => number + 1);

console.log(inflatedMarks);